#ifndef __PWM_H__
#define __PWM_H__
#include "alldef.h"

void TIM3_PWM_GPIO_Init(u16 arr,u16 psc);

#endif
