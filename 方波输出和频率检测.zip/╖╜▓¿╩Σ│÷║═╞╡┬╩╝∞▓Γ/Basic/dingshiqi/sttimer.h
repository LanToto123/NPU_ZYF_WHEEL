#ifndef __STTIMER_H__
#define __STTIMER_H__
#include "alldef.h"

void TIM3_Int_Init(u16 arr,u16 psc);

#endif
