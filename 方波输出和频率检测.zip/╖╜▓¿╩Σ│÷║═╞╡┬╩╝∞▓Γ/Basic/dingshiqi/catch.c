#include "alldef.h"
/*TIM4_CH1 PB6*/
void Catch_GPIO_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	TIM_ICInitTypeDef TIM_ICInitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	GPIO_ResetBits(GPIOB,GPIO_Pin_6);
	
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period=arr;
	TIM_TimeBaseStructure.TIM_Prescaler=psc;
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseStructure);
	
	TIM_ICInitStructure.TIM_Channel=TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICFilter=0x00;
	TIM_ICInitStructure.TIM_ICPolarity=TIM_ICPolarity_Rising;
	TIM_ICInitStructure.TIM_ICPrescaler=TIM_ICPSC_DIV1;
	TIM_ICInitStructure.TIM_ICSelection=TIM_ICSelection_DirectTI;
	TIM_ICInit(TIM4,&TIM_ICInitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_ITConfig(TIM4,TIM_IT_Update|TIM_IT_CC1,ENABLE);
	
	TIM_Cmd(TIM4,ENABLE);
}

u8 TIM4CH1_CAPTURE_STA=0;
u16 TIM4CH1_CAPTURE_VAL;


void TIM4_IRQHandler(void)
{
	if((TIM4CH1_CAPTURE_STA&0x80)==0)
	{
		if(TIM_GetITStatus(TIM4,TIM_IT_Update)!=RESET)
		{
			if(TIM4CH1_CAPTURE_STA&0x40)
			{
				if((TIM4CH1_CAPTURE_STA&0x3f)==0x3f)
				{
					TIM4CH1_CAPTURE_STA|=0x80;
					TIM4CH1_CAPTURE_VAL=0xffff;
				}
				else
				{
					TIM4CH1_CAPTURE_STA++;
				}
			}
		}
		
		if(TIM_GetITStatus(TIM4,TIM_IT_CC1)!=RESET)
		{
			if(TIM4CH1_CAPTURE_STA&0x40)
				{
					TIM4CH1_CAPTURE_STA|=0x80;
					TIM4CH1_CAPTURE_VAL=TIM_GetCapture1(TIM4);
					TIM_OC1PolarityConfig(TIM4,TIM_ICPolarity_Rising);
				}
				else
				{
					TIM4CH1_CAPTURE_STA=0;
					TIM4CH1_CAPTURE_VAL=0;
					TIM_SetCounter(TIM4,0);
					TIM4CH1_CAPTURE_STA|=0x40;
					TIM_OC1PolarityConfig(TIM4,TIM_ICPolarity_Falling);
				}
		}
	}
	
	TIM_ClearITPendingBit(TIM4,TIM_IT_CC1|TIM_IT_Update);
}
