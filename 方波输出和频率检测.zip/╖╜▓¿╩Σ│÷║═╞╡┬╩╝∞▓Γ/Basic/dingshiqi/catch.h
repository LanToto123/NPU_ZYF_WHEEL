#ifndef __CATCH_H__
#define __CATCH_H__
#include "alldef.h"
void Catch_GPIO_Init(u16 arr,u16 psc);
#endif
