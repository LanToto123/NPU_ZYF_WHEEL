#include "alldef.h"

void WatchDog_Init(u8 prer,u16 rlr)
//prerΪԤ��Ƶϵ����rlrΪ��װ��ֵ
{
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(prer);
	IWDG_SetReload(rlr);
	IWDG_ReloadCounter();
	IWDG_Enable();
}

/*���ڿ��Ź�*/
u8 WWDG_CNT=0x7f;
/*���ڿ��Ź�*/
void Window_WatchDog_Init(u8 tr,u8 wr,u32 fprer)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG,ENABLE);
	WWDG_CNT=tr&WWDG_CNT;
	WWDG_SetPrescaler(fprer);
	WWDG_SetWindowValue(wr);
	WWDG_Enable(WWDG_CNT);
	WWDG_ClearFlag();
	Window_WatchDog_NVIC_Init();
	WWDG_EnableIT();
}
//��ʼ��
void Window_WatchDog_Counter(u8 cnt)
{
	WWDG_Enable(cnt);
}
//���ü�����
void Window_WatchDog_NVIC_Init(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel=WWDG_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=3;
	NVIC_Init(&NVIC_InitStructure);
}

void WWDG_IRQHandler(void)
{
	//WWDG_SetCounter(WWDG_CNT);
	
	WWDG_ClearFlag();
	
	LED1=!LED1;
}
