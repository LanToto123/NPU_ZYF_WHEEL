#ifndef __UART_H__
#define __UART_H__
#include "sys.h"
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include "stdio.h"	
#define USART_REC_LEN 200
extern u16 USART_RX_STA;
extern u8 USART_RX_BUF[USART_REC_LEN];
void UART1_Init(void);


#endif
