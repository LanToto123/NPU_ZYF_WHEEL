#ifndef __ALLDEF_H__
#define __ALLDEF_H__

#include "stm32f10x.h" //STM32ͷ�ļ�
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "uart.h"
#include "stdio.h"
#include "exti.h"
#include "watchdog.h"
#include "sttimer.h"
#include "pwm.h"
#include "catch.h"

#endif
