#ifndef __EXTI_H
#define __EXTI_H	 
#include "sys.h"

void EXTIx_Init(void);

		 				    
#endif
